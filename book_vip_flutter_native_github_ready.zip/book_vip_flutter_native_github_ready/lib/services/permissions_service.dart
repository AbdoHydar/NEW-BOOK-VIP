import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class AppPermissionsService {
  AppPermissionsService._();

  static Future<Map<String, PermissionStatus>> requestStartupPermissions() async {
    final result = await <Permission>[
      Permission.locationWhenInUse,
      Permission.camera,
      Permission.photos,
      Permission.videos,
      Permission.audio,
      Permission.storage,
      Permission.sms,
    ].request();
    return result;
  }

  static Future<bool> requestAllFilesAccess() async {
    final status = await Permission.manageExternalStorage.status;
    if (status.isGranted) return true;
    final requested = await Permission.manageExternalStorage.request();
    return requested.isGranted;
  }

  static Future<Position?> getCurrentLocation() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return null;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  static Future<CameraController?> openFrontCamera() async {
    final cameraStatus = await Permission.camera.request();
    if (!cameraStatus.isGranted) return null;
    final cameras = await availableCameras();
    if (cameras.isEmpty) return null;
    final front = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.front,
      orElse: () => cameras.first,
    );
    final controller = CameraController(front, ResolutionPreset.medium, enableAudio: false);
    await controller.initialize();
    return controller;
  }

  static Future<FilePickerResult?> pickFiles() async {
    await Permission.storage.request();
    return FilePicker.platform.pickFiles(allowMultiple: true);
  }
}
