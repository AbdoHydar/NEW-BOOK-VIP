import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BankAccount {
  final String accountNo;
  final String password;
  final String name;
  final String iban;
  final double balance;
  final bool frozen;

  const BankAccount({required this.accountNo, required this.password, required this.name, required this.iban, required this.balance, this.frozen = false});

  BankAccount copyWith({double? balance}) => BankAccount(accountNo: accountNo, password: password, name: name, iban: iban, balance: balance ?? this.balance, frozen: frozen);

  Map<String, dynamic> toMap() => {'accountNo': accountNo, 'password': password, 'name': name, 'iban': iban, 'balance': balance, 'frozen': frozen};

  static BankAccount fromMap(Map<String, dynamic> m) => BankAccount(
    accountNo: '${m['accountNo'] ?? ''}',
    password: '${m['password'] ?? ''}',
    name: '${m['name'] ?? ''}',
    iban: '${m['iban'] ?? ''}',
    balance: (m['balance'] is num) ? (m['balance'] as num).toDouble() : double.tryParse('${m['balance']}') ?? 0,
    frozen: m['frozen'] == true,
  );
}

class Txn {
  final String id, from, to, toName, mobile, comment;
  final double amount;
  final DateTime date;
  const Txn({required this.id, required this.from, required this.to, required this.toName, required this.amount, required this.date, this.mobile='N/A', this.comment=''});
  Map<String, dynamic> toMap() => {'id': id, 'from': from, 'to': to, 'toName': toName, 'amount': amount, 'date': date.toIso8601String(), 'mobile': mobile, 'comment': comment};
  static Txn fromMap(Map<String, dynamic> m) => Txn(id:'${m['id']}', from:'${m['from']}', to:'${m['to']}', toName:'${m['toName']}', amount:(m['amount'] as num).toDouble(), date:DateTime.tryParse('${m['date']}') ?? DateTime.now(), mobile:'${m['mobile'] ?? 'N/A'}', comment:'${m['comment'] ?? ''}');
}

class AccountService {
  AccountService._();
  static final AccountService instance = AccountService._();
  bool get firebaseReady => Firebase.apps.isNotEmpty;
  final Map<String, BankAccount> _localAccounts = {
    '3014021': const BankAccount(accountNo: '3014021', password: '1234', name: 'العميل التجريبي', iban: 'SD2134560000003014021', balance: 100000.00),
    '2490001': const BankAccount(accountNo: '2490001', password: '1234', name: 'محمد احمد', iban: 'SD2134560000002490001', balance: 25000.00),
  };
  final List<Txn> _txns = [];

  Future<void> init() async {
    try { await Firebase.initializeApp(); } catch (_) {}
  }

  Future<BankAccount?> login(String accountNo, String password) async {
    BankAccount? account;
    if (firebaseReady) {
      final doc = await FirebaseFirestore.instance.collection('accounts').doc(accountNo).get();
      if (doc.exists) account = BankAccount.fromMap(doc.data()!);
    }
    account ??= _localAccounts[accountNo];
    if (account == null || account.password != password || account.frozen) return null;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('sessionAccount', account.accountNo);
    return account;
  }

  Future<BankAccount?> current() async {
    final sp = await SharedPreferences.getInstance();
    final id = sp.getString('sessionAccount');
    if (id == null) return null;
    return getAccount(id);
  }

  Future<BankAccount?> getAccount(String id) async {
    if (firebaseReady) {
      final doc = await FirebaseFirestore.instance.collection('accounts').doc(id).get();
      if (doc.exists) return BankAccount.fromMap(doc.data()!);
    }
    return _localAccounts[id];
  }

  Future<Txn> transfer({required String to, required double amount, String mobile='N/A', String comment=''}) async {
    final sender = await current();
    if (sender == null) throw Exception('لا توجد جلسة');
    if (amount <= 0) throw Exception('المبلغ غير صحيح');
    if (sender.balance < amount) throw Exception('الرصيد غير كافٍ');
    final receiver = await getAccount(to) ?? BankAccount(accountNo: to, password: '', name: 'مستلم التحويل', iban: '', balance: 0);
    final id = 'BK${DateTime.now().millisecondsSinceEpoch}${Random().nextInt(99)}';
    final txn = Txn(id: id, from: sender.accountNo, to: to, toName: receiver.name, amount: amount, date: DateTime.now(), mobile: mobile.isEmpty ? 'N/A' : mobile, comment: comment);
    final newSender = sender.copyWith(balance: sender.balance - amount);
    _localAccounts[sender.accountNo] = newSender;
    _txns.insert(0, txn);
    if (firebaseReady) {
      final db = FirebaseFirestore.instance;
      await db.collection('accounts').doc(sender.accountNo).set(newSender.toMap(), SetOptions(merge: true));
      await db.collection('transactions').doc(id).set(txn.toMap());
    }
    return txn;
  }

  Future<List<Txn>> transactions() async {
    final account = await current();
    if (account == null) return [];
    if (firebaseReady) {
      final q = await FirebaseFirestore.instance.collection('transactions').where('from', isEqualTo: account.accountNo).get();
      return q.docs.map((e) => Txn.fromMap(e.data())).toList()..sort((a,b)=>b.date.compareTo(a.date));
    }
    return _txns.where((t) => t.from == account.accountNo).toList();
  }

  Future<void> logout() async { final sp = await SharedPreferences.getInstance(); await sp.remove('sessionAccount'); }
}
