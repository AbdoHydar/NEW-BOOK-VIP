import 'package:flutter/material.dart';
import '../services/account_service.dart';
import 'ui.dart';

class MainScreen extends StatefulWidget { const MainScreen({super.key}); @override State<MainScreen> createState()=>_MainScreenState(); }
class _MainScreenState extends State<MainScreen>{ BankAccount? account; @override void initState(){super.initState(); AccountService.instance.current().then((v)=>setState(()=>account=v));}
  @override Widget build(BuildContext context)=>BankFrame(child:Positioned.fill(top:60, child:SingleChildScrollView(child:Column(children:[
    Container(width:double.infinity,padding:const EdgeInsets.fromLTRB(18,16,18,10), color:Colors.white, child:Text('نهارك سعيد ${account?.name ?? ''}', style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
    const SizedBox(height:12),
    Padding(padding:const EdgeInsets.symmetric(horizontal:14), child:GridView.count(crossAxisCount:3, shrinkWrap:true, physics:const NeverScrollableScrollPhysics(), mainAxisSpacing:12, crossAxisSpacing:12, childAspectRatio:.9, children:[
      _grid('assets/img/grid_1.png','تحويلات','/transfer'), _grid('assets/img/grid_2.png','دفع فواتير',''), _grid('assets/img/grid_3.png','تفاصيل الحساب','/page_account'),
      _grid('assets/img/grid_4.png','طلب الودائع الأستثمارية',''), _grid('assets/img/grid_5.png','بنككPAY',''), _grid('assets/img/grid_6.png','سحب بدون بطاقة',''),
      _grid('assets/img/grid_7.png','إدارة البطاقات',''), _grid('assets/img/grid_8.png','المعاملات السابقة','/transactions'), _grid('assets/img/grid_9.png','إدارةالمستفيدين',''),
      _grid('assets/img/grid_10.png','الضبط',''), _grid('assets/img/grid_11.png','امر دفع دائم',''), _grid('assets/img/grid_12.png','طلبات',''),
      _grid('assets/img/grid_13.png','خدمات العملات الاجنبية',''), _grid('assets/img/grid_14.png','التجارة الإلكترونية',''), _grid('assets/img/notification_icon.png','الإشعارات','/white'),
    ])), const SizedBox(height:20)
  ]))));
  Widget _grid(String img,String title,String route)=>GestureDetector(onTap:()=> route.isNotEmpty?Navigator.pushNamed(context, route):null, child:Container(color:Colors.white, padding:const EdgeInsets.all(8), child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Image.asset(img, width:52, height:52, errorBuilder:(_,__,___)=>const Icon(Icons.apps,size:42,color:red)), const SizedBox(height:8), Text(title, textAlign:TextAlign.center, style:const TextStyle(fontSize:12))])));
}
