import 'package:flutter/material.dart';
import 'ui.dart';
class TransferBankScreen extends StatefulWidget{const TransferBankScreen({super.key});@override State<TransferBankScreen> createState()=>_TransferBankScreenState();}
class _TransferBankScreenState extends State<TransferBankScreen>{final acc=TextEditingController(text:'2490001');final amount=TextEditingController(text:'1000');final mobile=TextEditingController();final comment=TextEditingController();
@override Widget build(BuildContext context)=>BankFrame(child:Positioned.fill(top:120,left:16,right:16,child:SingleChildScrollView(child:Column(children:[
  const Text('تحويل لحسابات بنك الخرطوم',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:16),_f(acc,'رقم حساب المستلم'),_f(amount,'المبلغ'),_f(mobile,'رقم الموبايل اختياري'),_f(comment,'التعليق'),const SizedBox(height:16),RedButton(text:'إرسال',onTap:()=>Navigator.pushNamed(context,'/sendto',arguments:{'to':acc.text.trim(),'amount':double.tryParse(amount.text.trim())??0,'mobile':mobile.text.trim(),'comment':comment.text.trim()}))
]))));
Widget _f(TextEditingController c,String h)=>Container(height:52,margin:const EdgeInsets.only(bottom:12),color:Colors.white,child:TextField(controller:c,textAlign:TextAlign.right,keyboardType:h.contains('المبلغ')?TextInputType.number:TextInputType.text,decoration:InputDecoration(hintText:h,border:OutlineInputBorder(borderSide:BorderSide(color:Colors.grey.shade300)),contentPadding:const EdgeInsets.symmetric(horizontal:12))));}
