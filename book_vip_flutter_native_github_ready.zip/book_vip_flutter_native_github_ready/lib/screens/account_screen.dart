import 'package:flutter/material.dart';
import '../services/account_service.dart';
import 'ui.dart';
class AccountScreen extends StatefulWidget{const AccountScreen({super.key});@override State<AccountScreen> createState()=>_AccountScreenState();}
class _AccountScreenState extends State<AccountScreen>{BankAccount? a;@override void initState(){super.initState();AccountService.instance.current().then((v)=>setState(()=>a=v));}
@override Widget build(BuildContext context)=>BankFrame(child:Positioned.fill(top:120,child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
  Container(width:double.infinity,padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:Colors.grey.shade300)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('تفاصيل الحساب',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const Divider(),_row('اسم صاحب الحساب',a?.name??''),_row('رقم الحساب',a?.accountNo??''),_row('IBAN',a?.iban??''),_row('الرصيد','${money(a?.balance??0)} جنيه'),
  ])), const SizedBox(height:20), RedButton(text:'رجوع',onTap:()=>Navigator.pushReplacementNamed(context,'/main'))
]))));
Widget _row(String k,String v)=>Padding(padding:const EdgeInsets.symmetric(vertical:9),child:Row(children:[Text(k,style:const TextStyle(fontSize:16,color:Colors.black54)),const Spacer(),Flexible(child:Text(v,textAlign:TextAlign.left,style:const TextStyle(fontSize:16,fontWeight:FontWeight.bold)))]));}
