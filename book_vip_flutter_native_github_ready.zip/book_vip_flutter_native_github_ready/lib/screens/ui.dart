import 'package:flutter/material.dart';
import '../services/account_service.dart';

const red = Color(0xffef1017);
const bg = Color(0xffededed);

class BankFrame extends StatelessWidget {
  final Widget child;
  final bool header;
  const BankFrame({super.key, required this.child, this.header = true});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        top: false,
        child: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 720),
            width: double.infinity,
            height: double.infinity,
            color: bg,
            child: Stack(children: [
              if (header) const AppHeader(),
              child,
            ]),
          ),
        ),
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key});
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Positioned(top: 0, left: 0, right: 0, height: 60, child: Container(color: red)),
      Positioned(top: 0, left: 0, right: 0, child: Center(child: Image.asset('assets/img/white_logo_n.png', width: 86, errorBuilder: (_, __, ___) => Image.asset('assets/img/bankak_logo_big.png', width: 86)))),
      Positioned(top: 17, right: 10, child: Image.asset('assets/img/drawable_backup/ic_drawer.png', width: 32, errorBuilder: (_, __, ___) => Image.asset('assets/img/ic_drawer.png', width: 32))),
      Positioned(top: 66, right: 6, child: GestureDetector(onTap: () => Navigator.of(context).pushReplacementNamed('/main'), child: Image.asset('assets/img/back.png', width: 72))),
    ]);
  }
}

class RedButton extends StatelessWidget {
  final String text; final VoidCallback onTap;
  const RedButton({super.key, required this.text, required this.onTap});
  @override Widget build(BuildContext context) => GestureDetector(onTap: onTap, child: Container(height: 46, alignment: Alignment.center, decoration: BoxDecoration(color: red, borderRadius: BorderRadius.circular(4)), child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold))));
}

String money(double v) => v.toStringAsFixed(2);
