import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/account_service.dart';
import 'ui.dart';
class TransactionsScreen extends StatefulWidget{const TransactionsScreen({super.key});@override State<TransactionsScreen> createState()=>_TransactionsScreenState();}
class _TransactionsScreenState extends State<TransactionsScreen>{List<Txn> tx=[];@override void initState(){super.initState();AccountService.instance.transactions().then((v)=>setState(()=>tx=v));}
@override Widget build(BuildContext context)=>BankFrame(child:Positioned.fill(top:120,left:12,right:12,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('المعاملات السابقة',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:10),Expanded(child:tx.isEmpty?const Center(child:Text('لا توجد معاملات سابقة')):ListView.builder(itemCount:tx.length,itemBuilder:(_,i){final t=tx[i];return GestureDetector(onTap:()=>Navigator.pushNamed(context,'/success',arguments:t),child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(12),color:Colors.white,child:Row(children:[Image.asset('assets/img/notification_icon.png',width:34),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('تحويل إلى ${t.toName}',style:const TextStyle(fontWeight:FontWeight.bold)),Text(DateFormat('yyyy/MM/dd HH:mm').format(t.date),style:const TextStyle(fontSize:12,color:Colors.black54))])),Text('${money(t.amount)} جنيه',style:const TextStyle(color:red,fontWeight:FontWeight.bold))])));})),])));
}
