import 'package:flutter/material.dart';
import 'ui.dart';
class TransferScreen extends StatelessWidget{const TransferScreen({super.key});@override Widget build(BuildContext context)=>BankFrame(child:Positioned.fill(top:122,left:12,right:12,child:Column(children:[
  _opt(context,'assets/img/ftothacc.png','تحويل لحسابات بنك الخرطوم','/transferbank'),const SizedBox(height:10),
  _opt(context,'assets/img/ftmobileacc.png','الدفع عبر الموبايل','/transferbank'),const SizedBox(height:10),
  _opt(context,'assets/img/drawable_backup/cardsupplementary.png','تحويل لبنك آخر باستخدام رقم البطاقة','/transferbank'),
])));
Widget _opt(BuildContext context,String icon,String title,String route)=>GestureDetector(onTap:()=>Navigator.pushNamed(context,route),child:Container(height:62,decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xffdddddd)),boxShadow:const [BoxShadow(color:Colors.black26,blurRadius:1,offset:Offset(0,1))]),child:Row(textDirection:TextDirection.rtl,children:[const SizedBox(width:6),Image.asset(icon,width:45,height:45),const SizedBox(width:10),Expanded(child:Text(title,textAlign:TextAlign.right,style:const TextStyle(fontSize:14,color:Color(0xff222222)))),Transform.scale(scaleX:1,child:Image.asset('assets/img/listarr.png',width:27,height:27)),const SizedBox(width:7)])));
}
