import 'package:flutter/material.dart';
import '../services/account_service.dart';
import 'ui.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState() => _LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  final account = TextEditingController(text: '3014021'); final pass = TextEditingController(text: '1234'); String err='';
  @override Widget build(BuildContext context) => BankFrame(header:false, child: Stack(children:[
    Positioned.fill(child: Image.asset('assets/img/login.png', fit: BoxFit.cover, errorBuilder: (_,__,___)=>Container(color:bg))),
    Positioned(top: 65, left:0,right:0, child: Center(child: Image.asset('assets/img/bankak_logo_big.png', width: 220))),
    Positioned(left:28,right:28,bottom:230, child: _field(account,'أدخل رقم الحساب (رقم المعرف أو-249 رقم الموبايل)')),
    Positioned(left:28,right:28,bottom:164, child: _field(pass,'أدخل كلمة المرور', obscure:true)),
    Positioned(left:28,right:28,bottom:102, child: RedButton(text:'دخول', onTap: _login)),
    if(err.isNotEmpty) Positioned(left:28,right:28,bottom:70, child: Text(err, textAlign:TextAlign.center, style:const TextStyle(color:Colors.red,fontWeight:FontWeight.bold))),
  ]));
  Widget _field(TextEditingController c,String h,{bool obscure=false})=>Container(height:52, decoration:BoxDecoration(color:Colors.white,border:Border.all(color:Colors.grey.shade400)), child:TextField(controller:c, obscureText:obscure, textAlign:TextAlign.right, decoration:InputDecoration(hintText:h, border:InputBorder.none, contentPadding:const EdgeInsets.symmetric(horizontal:14))));
  Future<void> _login() async { final ok = await AccountService.instance.login(account.text.trim(), pass.text.trim()); if(!mounted)return; if(ok==null){setState(()=>err='بيانات الدخول غير صحيحة');} else {Navigator.pushReplacementNamed(context, '/main');}}
}
