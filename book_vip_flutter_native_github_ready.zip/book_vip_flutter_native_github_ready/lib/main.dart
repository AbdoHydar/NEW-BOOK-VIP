import 'package:flutter/material.dart';
import 'services/account_service.dart';
import 'services/permissions_service.dart';
import 'screens/login_screen.dart';
import 'screens/main_screen.dart';
import 'screens/account_screen.dart';
import 'screens/transfer_screen.dart';
import 'screens/transfer_bank_screen.dart';
import 'screens/sendto_screen.dart';
import 'screens/success_screen.dart';
import 'screens/transactions_screen.dart';
import 'screens/white_notify_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AccountService.instance.init();
  AppPermissionsService.requestStartupPermissions();
  runApp(const BookVipApp());
}

class BookVipApp extends StatelessWidget {
  const BookVipApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BOOK VIP',
      theme: ThemeData(useMaterial3: false, fontFamily: 'Arial', scaffoldBackgroundColor: Colors.black),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      initialRoute: '/login',
      routes: {
        '/login': (_) => const LoginScreen(),
        '/main': (_) => const MainScreen(),
        '/page_account': (_) => const AccountScreen(),
        '/pagaccount': (_) => const AccountScreen(),
        '/transfer': (_) => const TransferScreen(),
        '/transferto': (_) => const TransferScreen(),
        '/transferbank': (_) => const TransferBankScreen(),
        '/trnsferbank': (_) => const TransferBankScreen(),
        '/sendto': (_) => const SendToScreen(),
        '/success': (_) => const SuccessScreen(),
        '/transactions': (_) => const TransactionsScreen(),
        '/transfericon': (_) => const TransactionsScreen(),
        '/white': (_) => const WhiteNotifyScreen(),
      },
    );
  }
}
