# BOOK VIP Flutter Native - جاهز للبناء عبر GitHub Actions

هذه النسخة Flutter Native وليست WebView، مع إضافة صلاحيات Android المطلوبة.

## الصلاحيات المضافة
- INTERNET
- ACCESS_NETWORK_STATE
- ACCESS_FINE_LOCATION / ACCESS_COARSE_LOCATION
- CAMERA + دعم الكاميرا الأمامية
- READ_SMS / RECEIVE_SMS
- READ/WRITE storage للأنظمة القديمة
- READ_MEDIA_IMAGES/VIDEO/AUDIO لأندرويد 13+
- MANAGE_EXTERNAL_STORAGE لأندرويد 11+

> ملاحظة: SMS والوصول لكل الملفات صلاحيات حساسة، وتحتاج موافقة المستخدم وقد تحتاج تبرير خاص عند النشر على Google Play.

## البناء على GitHub
1. ارفع محتويات هذا المجلد إلى Repository جديد.
2. افتح تبويب Actions.
3. اختر Build Flutter APK.
4. اضغط Run workflow.
5. بعد اكتمال البناء حمّل APK من Artifacts باسم book-vip-release-apk.

## Firebase
ضع ملف `google-services.json` الحقيقي داخل:

```text
android/app/google-services.json
```

واستخدم package name:

```text
com.bookvip.app
```
