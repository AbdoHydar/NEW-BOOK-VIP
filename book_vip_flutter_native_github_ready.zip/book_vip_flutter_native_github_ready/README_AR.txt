نسخة Flutter حقيقية Native وليست WebView.

الصفحات المضمنة:
login -> main -> page_account -> transfer -> transferbank -> sendto -> success
transactions / transfericon -> white

الربط:
- التطبيق يستخدم Firebase Core + Cloud Firestore عند إضافة ملفات Firebase الحقيقية.
- إذا لم يتم إعداد Firebase يعمل بقاعدة محلية تجريبية حتى تستطيع فحص التصميم.
- الرصيد في صفحة تفاصيل الحساب يأتي من AccountService وليس قيمة ثابتة.

الحساب التجريبي:
3014021 / 1234

تشغيل:
flutter pub get
flutter run

بناء APK:
flutter build apk --release

لتفعيل Firebase الحقيقي:
1) أنشئ مشروع Firebase.
2) أضف تطبيق Android بالحزمة: com.bookvip.app
3) حمّل google-services.json داخل android/app/
4) نفّذ flutterfire configure أو أضف إعدادات Firebase المناسبة.
5) أنشئ collections: accounts و transactions.

لوحة الأدمن الخارجية موجودة خارج التطبيق في مجلد admin_external_native.
